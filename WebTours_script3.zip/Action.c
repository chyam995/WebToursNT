Action()
{
	int think;
	think=atoi(lr_eval_string("{thinktime}"));
	
	web_reg_save_param_ex(
	"ParamName=userSession",
	"LB=<input type=\"hidden\" name=\"userSession\" value=\"",
	"RB=\"",
	SEARCH_FILTERS,
	"IgnoreRedirections=off",
	"Scope=Body",
	"RequestUrl=*",
	LAST);
lr_start_transaction("S3_view_tickets");
	web_url("Webtours", 
		"URL=http://localhost:1080/Webtours/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(think);

	lr_start_transaction("Login");
	
	web_submit_data("login.pl",
		"Action=http://localhost:1080/cgi-bin/login.pl",
		"Method=POST",
		"TargetFrame=body",
		"RecContentType=text/html",
		"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home",
		"Snapshot=t4.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=userSession", "Value=127678.358768732zfzHtffpfHQVzzzHDQtAtpHDDtHf", ENDITEM,
		"Name=username", "Value={username}", ENDITEM,
		"Name=password", "Value={Password}", ENDITEM,
		"Name=JSFormSubmit", "Value=off", ENDITEM,
		"Name=login.x", "Value=43", ENDITEM,
		"Name=login.y", "Value=4", ENDITEM,
		LAST);

	lr_end_transaction("Login",LR_AUTO);

	lr_think_time(think);

	lr_start_transaction("S3_itinerary");

	web_url("Itinerary Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=itinerary", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("S3_itinerary",LR_AUTO);

	lr_think_time(think);

	lr_start_transaction("S3_Flights");

	web_url("Search Flights Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=search", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=itinerary", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		LAST);

	lr_think_time(think);

	web_submit_data("reservations.pl",
		"Action=http://localhost:1080/cgi-bin/reservations.pl",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=http://localhost:1080/cgi-bin/reservations.pl?page=welcome",
		"Snapshot=t7.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=advanceDiscount", "Value=0", ENDITEM,
		"Name=depart", "Value={cityD}", ENDITEM,
		"Name=departDate", "Value=12/14/2019", ENDITEM,
		"Name=arrive", "Value={cityA}", ENDITEM,
		"Name=returnDate", "Value=12/27/2019", ENDITEM,
		"Name=numPassengers", "Value={numPassenger}", ENDITEM,
		"Name=seatPref", "Value={SeatPref}", ENDITEM,
		"Name=seatType", "Value={seatType}", ENDITEM,
		"Name=.cgifields", "Value=roundtrip", ENDITEM,
		"Name=.cgifields", "Value=seatType", ENDITEM,
		"Name=.cgifields", "Value=seatPref", ENDITEM,
		"Name=findFlights.x", "Value=38", ENDITEM,
		"Name=findFlights.y", "Value=10", ENDITEM,
		LAST);

	lr_think_time(think);

	web_submit_data("reservations.pl_2",
		"Action=http://localhost:1080/cgi-bin/reservations.pl",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=http://localhost:1080/cgi-bin/reservations.pl",
		"Snapshot=t8.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=outboundFlight", "Value=030;251;12/14/2019", ENDITEM,
		"Name=numPassengers", "Value={numPassenger}", ENDITEM,
		"Name=advanceDiscount", "Value=0", ENDITEM,
		"Name=seatType", "Value={seatType}", ENDITEM,
		"Name=seatPref", "Value={SeatPref}", ENDITEM,
		"Name=reserveFlights.x", "Value=42", ENDITEM,
		"Name=reserveFlights.y", "Value=10", ENDITEM,
		LAST);

	lr_end_transaction("S3_Flights",LR_AUTO);

	lr_think_time(think);

	lr_start_transaction("S3_Itinerary");

	web_url("Itinerary Button_2", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?page=itinerary", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=flights", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("S3_Itinerary",LR_AUTO);

	lr_think_time(think);

	lr_start_transaction("Logout");

	web_url("SignOff Button", 
		"URL=http://localhost:1080/cgi-bin/welcome.pl?signOff=1", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=http://localhost:1080/cgi-bin/nav.pl?page=menu&in=itinerary", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Logout",LR_AUTO);

	lr_end_transaction("S3_view_tickets",LR_AUTO);

	return 0;
}