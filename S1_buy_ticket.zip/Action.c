Action()
{
	int think;
	think=atoi(lr_eval_string("{thinktime}"));
	web_reg_save_param_ex(
	"ParamName=userSession_1",
	"LB=<input type=\"hidden\" name=\"userSession\" value=\"",
	"RB=\"",
	SEARCH_FILTERS,
	"IgnoreRedirections=off",
	"Scope=Body",
	"RequestUrl=*",
	LAST);
lr_start_transaction("S1_buy_ticket");

	web_url("Webtours", 
		"URL={URL}Webtours/", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		LAST);
	lr_think_time(think);
	
	lr_start_transaction("Login");

	web_reg_find("Fail=NotFound",
		"Search=Body",
		"Text=Welcome",
		LAST);

	web_submit_data("login.pl",
		"Action={URL}cgi-bin/login.pl",
		"Method=POST",
		"TargetFrame=body",
		"RecContentType=text/html",
		"Referer=http://localhost:1080/cgi-bin/nav.pl?in=home",
		"Snapshot=t2.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=userSession", "Value={userSession_1}", ENDITEM,
		"Name=username", "Value={username}", ENDITEM,
		"Name=password", "Value={password}", ENDITEM,
		"Name=JSFormSubmit", "Value=off", ENDITEM,
		"Name=login.x", "Value=36", ENDITEM,
		"Name=login.y", "Value=9", ENDITEM,
		LAST);
	

	lr_end_transaction("Login",LR_AUTO);

	lr_think_time(think);

	lr_start_transaction("S1_�����_�����_������_�_�������");

	web_url("Search Flights Button", 
		"URL={URL}cgi-bin/welcome.pl?page=search", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={URL}cgi-bin/nav.pl?page=menu&in=home", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		LAST);

	web_submit_data("reservations.pl",
		"Action={URL}cgi-bin/reservations.pl",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer={URL}cgi-bin/reservations.pl?page=welcome",
		"Snapshot=t4.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=advanceDiscount", "Value=0", ENDITEM,
		"Name=depart", "Value={city}", ENDITEM,
		"Name=departDate", "Value=12/13/2019", ENDITEM,
		"Name=arrive", "Value={city}", ENDITEM,
		"Name=returnDate", "Value=12/30/2019", ENDITEM,
		"Name=numPassengers", "Value=1", ENDITEM,
		"Name=seatPref", "Value={SeatPref}", ENDITEM,
		"Name=seatType", "Value={seatType}", ENDITEM,
		"Name=.cgifields", "Value=roundtrip", ENDITEM,
		"Name=.cgifields", "Value=seatType", ENDITEM,
		"Name=.cgifields", "Value=seatPref", ENDITEM,
		"Name=findFlights.x", "Value=22", ENDITEM,
		"Name=findFlights.y", "Value=11", ENDITEM,
		LAST);

	web_submit_data("reservations.pl_2",
		"Action={URL}cgi-bin/reservations.pl",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer={URL}cgi-bin/reservations.pl",
		"Snapshot=t5.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=outboundFlight", "Value=021;301;12/13/2019", ENDITEM,
		"Name=numPassengers", "Value={numPessenger}", ENDITEM,
		"Name=advanceDiscount", "Value=0", ENDITEM,
		"Name=seatType", "Value={seatType}", ENDITEM,
		"Name=seatPref", "Value={SeatPref}", ENDITEM,
		"Name=reserveFlights.x", "Value=26", ENDITEM,
		"Name=reserveFlights.y", "Value=5", ENDITEM,
		LAST);

	lr_end_transaction("S1_�����_�����_������_�_�������",LR_AUTO);

	lr_think_time(think);

	lr_start_transaction("S1_���� ������ ����� � ������");

	web_submit_data("reservations.pl_3",
		"Action={URL}cgi-bin/reservations.pl",
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer={URL}cgi-bin/reservations.pl",
		"Snapshot=t6.inf",
		"Mode=HTML",
		ITEMDATA,
		"Name=firstName", "Value=Jojo", ENDITEM,
		"Name=lastName", "Value=Bean", ENDITEM,
		"Name=address1", "Value=", ENDITEM,
		"Name=address2", "Value=", ENDITEM,
		"Name=pass1", "Value=Jojo Bean", ENDITEM,
		"Name=creditCard", "Value=123456789", ENDITEM,
		"Name=expDate", "Value=2019", ENDITEM,
		"Name=oldCCOption", "Value=", ENDITEM,
		"Name=numPassengers", "Value={numPessenger}", ENDITEM,
		"Name=seatType", "Value={seatType}", ENDITEM,
		"Name=seatPref", "Value={SeatPref}", ENDITEM,
		"Name=outboundFlight", "Value=021;301;12/13/2019", ENDITEM,
		"Name=advanceDiscount", "Value=0", ENDITEM,
		"Name=returnFlight", "Value=", ENDITEM,
		"Name=JSFormSubmit", "Value=off", ENDITEM,
		"Name=.cgifields", "Value=saveCC", ENDITEM,
		"Name=buyFlights.x", "Value=29", ENDITEM,
		"Name=buyFlights.y", "Value=12", ENDITEM,
		LAST);

	lr_end_transaction("S1_���� ������ ����� � ������",LR_AUTO);
	
	lr_think_time(think);
	
	lr_start_transaction("Logout");

	web_url("SignOff Button", 
		"URL={URL}cgi-bin/welcome.pl?signOff=1", 
		"TargetFrame=body", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer={URL}cgi-bin/nav.pl?page=menu&in=flights", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		LAST);

	lr_end_transaction("Logout",LR_AUTO);

	lr_end_transaction("S1_buy_ticket",LR_AUTO);

	return 0;
}